import { Component } from '@angular/core';

@Component({
  selector: 'app-vieo',
  templateUrl: './vieo.component.html',
  styleUrls: ['./vieo.component.css']
})
export class VieoComponent {

}
